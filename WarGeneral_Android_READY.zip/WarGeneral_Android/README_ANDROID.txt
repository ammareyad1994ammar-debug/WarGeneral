WAR GENERAL v16 - Android Ready

هذه نسخة منفصلة من المشروع، والنسخة الاحتياطية v16 الأصلية لم يتم تعديلها.

Unity: 2022.3.45f1
المشهد للبناء: Assets/Scenes/Main.unity

لبناء APK داخل Unity:
1) افتح المشروع في Unity 2022.3.45f1 مع تثبيت Android Build Support.
2) من القائمة: War General > Build Android APK
3) سيُنشأ الملف: Builds/WarGeneral_v16.apk

ملاحظة: وجود هذا السكربت لا يعني أن APK تم بناؤه بالفعل؛ عملية البناء تحتاج Unity Editor مع Android Build Support.
