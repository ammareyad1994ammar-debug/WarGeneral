#if UNITY_EDITOR
using UnityEditor;
using UnityEditor.Build.Reporting;
using UnityEngine;
using System.IO;

public static class BuildAndroid
{
    [MenuItem("War General/Build Android APK")]
    public static void BuildAPK()
    {
        const string output = "Builds/WarGeneral_v16.apk";
        Directory.CreateDirectory(Path.GetDirectoryName(output));
        EditorUserBuildSettings.SwitchActiveBuildTarget(BuildTargetGroup.Android, BuildTarget.Android);
        PlayerSettings.applicationIdentifier = "com.wargeneral.prototype";
        PlayerSettings.productName = "War General";
        PlayerSettings.companyName = "War General";
        PlayerSettings.Android.minSdkVersion = AndroidSdkVersions.AndroidApiLevel22;
        PlayerSettings.Android.targetSdkVersion = AndroidSdkVersions.AndroidApiLevelAuto;
        var scenes = new[] { "Assets/Scenes/Main.unity" };
        var options = new BuildPlayerOptions
        {
            scenes = scenes,
            locationPathName = output,
            target = BuildTarget.Android,
            options = BuildOptions.None
        };
        BuildReport report = BuildPipeline.BuildPlayer(options);
        if (report.summary.result == BuildResult.Succeeded)
            Debug.Log("War General APK created: " + Path.GetFullPath(output));
        else
            Debug.LogError("Android build failed: " + report.summary.result);
    }
}
#endif
