
using UnityEngine;
using UnityEngine.UI;
using System.Collections.Generic;

public class WarGeneralBootstrap : MonoBehaviour
{
    public Material friendlyMat, enemyMat, groundMat;
    public Font font;

    void Start()
    {
        Application.targetFrameRate = 60;
        BuildWorld();
        BuildUI();
    }

    void BuildWorld()
    {
        // Ground
        GameObject ground = GameObject.CreatePrimitive(PrimitiveType.Plane);
        ground.name = "Battlefield";
        ground.transform.localScale = new Vector3(12,1,12);
        groundMat = MakeMat(new Color(0.16f,0.25f,0.12f));
        ground.GetComponent<Renderer>().material = groundMat;

        // River
        GameObject river = GameObject.CreatePrimitive(PrimitiveType.Cube);
        river.name = "River";
        river.transform.position = new Vector3(0,0.03f,5);
        river.transform.localScale = new Vector3(22,0.05f,2.2f);
        river.GetComponent<Renderer>().material = MakeMat(new Color(0.05f,0.35f,0.65f));

        // Bridge
        GameObject bridge = GameObject.CreatePrimitive(PrimitiveType.Cube);
        bridge.name = "Bridge";
        bridge.transform.position = new Vector3(0,0.15f,5);
        bridge.transform.localScale = new Vector3(3,0.3f,3);
        bridge.GetComponent<Renderer>().material = MakeMat(new Color(0.3f,0.3f,0.3f));

        // Base
        GameObject baseObj = CreateBase(new Vector3(8,0,9), false);
        baseObj.name = "EnemyBase";

        // Friendly units
        CreateTank(new Vector3(-7,0.35f,-7), true);
        CreateTank(new Vector3(-4,0.35f,-6), true);
        CreateSoldier(new Vector3(-6,0,-4), true);
        CreateSoldier(new Vector3(-4,0,-4), true);
        CreateSoldier(new Vector3(-5,0,-3), true);
        CreateHelicopter(new Vector3(-2,4,-4), true);

        // Enemy units
        CreateTank(new Vector3(5,0.35f,7), false);
        CreateSoldier(new Vector3(6,0,6), false);
        CreateSoldier(new Vector3(7,0,7), false);

        // Camera
        GameObject camObj = new GameObject("StrategyCamera");
        Camera cam = camObj.AddComponent<Camera>();
        camObj.AddComponent<AudioListener>();
        camObj.transform.position = new Vector3(0,18,-16);
        camObj.transform.rotation = Quaternion.Euler(48,0,0);
        cam.fieldOfView = 55;
        camObj.AddComponent<RTSCamera>();
        var mobile = gameObject.AddComponent<MobileControlsV5>();
        mobile.cam = cam;
        var hud = gameObject.AddComponent<MobileHUDV6>();
        hud.controls = mobile;
        var commands = gameObject.AddComponent<CommandSystemV7>();
        commands.controls = mobile;
        hud.commands = commands;

        // Commander
        GameObject commander = GameObject.Find("Commander");
        if (commander == null)
        {
            commander = new GameObject("Commander");
            var click = commander.AddComponent<ClickCommander>();
            click.cam = cam;
        }

        var gm = gameObject.AddComponent<GameManagerV2>();
        gm.enemyBase = baseObj.transform;
        gm.missionText = GameObject.Find("MissionText")?.GetComponent<Text>();

        var mm = gameObject.AddComponent<MissionManagerV4>();
        mm.enemyBase = baseObj.transform;
        mm.missionText = GameObject.Find("MissionText")?.GetComponent<Text>();
        mm.statusText = GameObject.Find("StatusText")?.GetComponent<Text>();
    }

    GameObject CreateBase(Vector3 pos, bool friendly)
    {
        GameObject root = new GameObject(friendly ? "FriendlyBase" : "EnemyBase");
        root.transform.position = pos;
        for(int i=0;i<5;i++)
        {
            GameObject b = GameObject.CreatePrimitive(PrimitiveType.Cube);
            b.transform.SetParent(root.transform);
            b.transform.localPosition = new Vector3((i-2)*1.4f,0.7f, (i%2)*1.2f);
            b.transform.localScale = new Vector3(1.1f,1.4f,1.1f);
            b.GetComponent<Renderer>().material = MakeMat(friendly ? new Color(0.12f,0.35f,0.65f) : new Color(0.55f,0.12f,0.08f));
        }
        return root;
    }

    void CreateTank(Vector3 pos, bool friendly)
    {
        GameObject root = new GameObject(friendly ? "FriendlyTank" : "EnemyTank");
        root.transform.position = pos;
        GameObject body = GameObject.CreatePrimitive(PrimitiveType.Cube);
        body.transform.SetParent(root.transform);
        body.transform.localScale = new Vector3(2.1f,0.55f,1.3f);
        body.GetComponent<Renderer>().material = MakeMat(friendly ? new Color(0.18f,0.32f,0.16f) : new Color(0.38f,0.16f,0.12f));
        GameObject turret = GameObject.CreatePrimitive(PrimitiveType.Cylinder);
        turret.transform.SetParent(root.transform);
        turret.transform.localPosition = new Vector3(0,0.45f,0);
        turret.transform.localScale = new Vector3(0.55f,0.18f,0.55f);
        turret.GetComponent<Renderer>().material = body.GetComponent<Renderer>().material;
        GameObject barrel = GameObject.CreatePrimitive(PrimitiveType.Cube);
        barrel.transform.SetParent(root.transform);
        barrel.transform.localPosition = new Vector3(0,0.48f,0.9f);
        barrel.transform.localScale = new Vector3(0.16f,0.16f,1.2f);
        barrel.GetComponent<Renderer>().material = body.GetComponent<Renderer>().material;
        root.AddComponent<UnitController>();
        var combat = root.AddComponent<CombatUnit>();
        combat.team = friendly ? 0 : 1;
    }

    void CreateSoldier(Vector3 pos, bool friendly)
    {
        GameObject root = GameObject.CreatePrimitive(PrimitiveType.Capsule);
        root.name = friendly ? "FriendlySoldier" : "EnemySoldier";
        root.transform.position = pos + Vector3.up*0.7f;
        root.transform.localScale = new Vector3(0.35f,0.7f,0.35f);
        root.GetComponent<Renderer>().material = MakeMat(friendly ? new Color(0.08f,0.28f,0.12f) : new Color(0.5f,0.08f,0.08f));
        root.AddComponent<UnitController>();
        var combat = root.AddComponent<CombatUnit>();
        combat.team = friendly ? 0 : 1;
    }

    void CreateHelicopter(Vector3 pos, bool friendly)
    {
        GameObject root = GameObject.CreatePrimitive(PrimitiveType.Capsule);
        root.name = friendly ? "FriendlyHelicopter" : "EnemyHelicopter";
        root.transform.position = pos;
        root.transform.localScale = new Vector3(1.2f,0.35f,2.1f);
        root.GetComponent<Renderer>().material = MakeMat(friendly ? new Color(0.12f,0.25f,0.16f) : new Color(0.4f,0.1f,0.1f));
        root.AddComponent<UnitController>();
        var combat = root.AddComponent<CombatUnit>();
        combat.team = friendly ? 0 : 1;
        combat.maxHealth = 140f;
        combat.damage = 30f;
        combat.attackRange = 18f;
    }

    void BuildUI()
    {
        GameObject canvasObj = new GameObject("HUD");
        Canvas canvas = canvasObj.AddComponent<Canvas>();
        canvas.renderMode = RenderMode.ScreenSpaceOverlay;
        canvasObj.AddComponent<CanvasScaler>();
        canvasObj.AddComponent<GraphicRaycaster>();

        Text title = MakeText(canvasObj.transform, "WAR GENERAL", 28, new Vector2(20,-20), TextAnchor.UpperLeft);
        title.color = Color.white;

        Text mission = MakeText(canvasObj.transform, "المهمة الرئيسية: اقتحم قاعدة العدو", 22, new Vector2(20,-65), TextAnchor.UpperLeft);
        mission.name = "MissionText";
        mission.color = Color.yellow;

        Text help = MakeText(canvasObj.transform, "اضغط على وحدة ثم اضغط على الأرض لتحريكها", 18, new Vector2(20,20), TextAnchor.LowerLeft);
        help.color = Color.white;

        Text mobile = MakeText(canvasObj.transform, "📱 لمس الوحدة ثم لمس الأرض للتحرك", 18, new Vector2(-20,20), TextAnchor.LowerRight);
        mobile.color = Color.white;

        Text status = MakeText(canvasObj.transform, "READY", 24, new Vector2(-20,-75), TextAnchor.UpperRight);
        status.name = "StatusText";
        status.color = Color.cyan;

        Text resources = MakeText(canvasObj.transform, "🪙 125,600     💎 2,450     ⚡ 85/100", 20, new Vector2(-20,-20), TextAnchor.UpperRight);
        resources.color = Color.white;
    }

    Text MakeText(Transform parent, string value, int size, Vector2 pos, TextAnchor anchor)
    {
        GameObject go = new GameObject("Text");
        go.transform.SetParent(parent, false);
        Text t = go.AddComponent<Text>();
        t.text = value;
        t.font = Resources.GetBuiltinResource<Font>("Arial.ttf");
        t.fontSize = size;
        t.alignment = anchor;
        RectTransform r = t.rectTransform;
        r.anchorMin = anchor == TextAnchor.UpperRight ? new Vector2(1,1) : new Vector2(0,1);
        r.anchorMax = r.anchorMin;
        r.pivot = r.anchorMin;
        r.anchoredPosition = pos;
        r.sizeDelta = new Vector2(650,80);
        return t;
    }

    Material MakeMat(Color c)
    {
        Material m = new Material(Shader.Find("Standard"));
        m.color = c;
        return m;
    }
}
