
using UnityEngine;
using UnityEngine.UI;

public class MobileHUDV6 : MonoBehaviour
{
    public MobileControlsV5 controls;
    public CommandSystemV7 commands;
    Text selectedText;

    void Start()
    {
        Canvas canvas = FindObjectOfType<Canvas>();
        if (!canvas) return;

        selectedText = MakeText(canvas.transform, "لم يتم اختيار وحدة", 18,
            new Vector2(0, 70), new Vector2(0.5f, 0));
        selectedText.alignment = TextAnchor.MiddleCenter;

        MakeButton(canvas.transform, "هجوم", new Vector2(-130, 55), new Vector2(120, 60),
            () => { if(commands) commands.Attack(); SendCommand("هجوم"); });
        MakeButton(canvas.transform, "دفاع", new Vector2(0, 55), new Vector2(120, 60),
            () => { if(commands) commands.Defend(); SendCommand("دفاع"); });
        MakeButton(canvas.transform, "استدعاء", new Vector2(130, 55), new Vector2(120, 60),
            () => { if(commands) commands.Reinforce(); SendCommand("استدعاء"); });
    }

    void Update()
    {
        if (selectedText && controls && controls.selected)
            selectedText.text = "الوحدة المختارة: " + controls.selected.name;
    }

    void SendCommand(string command)
    {
        if (selectedText) selectedText.text = "الأمر: " + command;
    }

    Text MakeText(Transform parent, string value, int size, Vector2 pos, Vector2 anchor)
    {
        GameObject go = new GameObject("HUDText");
        go.transform.SetParent(parent, false);
        Text t = go.AddComponent<Text>();
        t.font = Resources.GetBuiltinResource<Font>("Arial.ttf");
        t.fontSize = size;
        t.text = value;
        t.color = Color.white;
        RectTransform r = t.rectTransform;
        r.anchorMin = anchor;
        r.anchorMax = anchor;
        r.pivot = anchor;
        r.anchoredPosition = pos;
        r.sizeDelta = new Vector2(500, 50);
        return t;
    }

    void MakeButton(Transform parent, string label, Vector2 pos, Vector2 size, UnityEngine.Events.UnityAction action)
    {
        GameObject go = new GameObject("Button_" + label);
        go.transform.SetParent(parent, false);
        Image img = go.AddComponent<Image>();
        img.color = new Color(0.05f,0.08f,0.1f,0.88f);
        Button b = go.AddComponent<Button>();
        b.onClick.AddListener(action);

        Text t = MakeText(go.transform, label, 18, Vector2.zero, new Vector2(0.5f,0.5f));
        t.alignment = TextAnchor.MiddleCenter;

        RectTransform r = go.GetComponent<RectTransform>();
        r.anchorMin = new Vector2(0.5f,0);
        r.anchorMax = new Vector2(0.5f,0);
        r.pivot = new Vector2(0.5f,0);
        r.anchoredPosition = pos;
        r.sizeDelta = size;
    }
}
