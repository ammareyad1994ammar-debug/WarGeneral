
using UnityEngine;

public class UnitUpgradeV11 : MonoBehaviour
{
    public int level = 1;
    public int cost = 50;

    public bool Upgrade(){
        var u=GetComponent<CombatUnit>();
        var e=FindObjectOfType<EconomyV11>();
        if(u==null || e==null || !e.Spend(cost)) return false;

        level++;
        u.damage += 3;
        u.maxHealth += 15;
        cost += 25;
        return true;
    }
}
