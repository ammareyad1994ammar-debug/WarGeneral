
using UnityEngine;
public class ClickCommander : MonoBehaviour
{
    public Camera cam;
    public UnitController selectedUnit;
    void Update()
    {
        if(!Input.GetMouseButtonDown(0)) return;
        Ray ray=cam.ScreenPointToRay(Input.mousePosition);
        if(!Physics.Raycast(ray,out RaycastHit hit,500f)) return;
        UnitController unit=hit.collider.GetComponentInParent<UnitController>();
        if(unit!=null && unit.name.StartsWith("Friendly")) { selectedUnit=unit; return; }
        if(selectedUnit!=null) selectedUnit.MoveTo(hit.point);
    }
}
