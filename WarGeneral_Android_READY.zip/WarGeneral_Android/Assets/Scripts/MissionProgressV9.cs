
using UnityEngine;

public class MissionProgressV9 : MonoBehaviour
{
    public int objective = 5;
    public int destroyed;

    public void EnemyDestroyed(){
        destroyed++;
        if(BattleSystemsV9.Instance!=null)
            BattleSystemsV9.Instance.Reward(10);
    }

    public float Progress(){
        return Mathf.Clamp01((float)destroyed/objective);
    }
}
