
using UnityEngine;

public enum UnitTypeV10 { Soldier, Tank, Scout }

public class UnitTypesV10 : MonoBehaviour
{
    public UnitTypeV10 type = UnitTypeV10.Soldier;

    public void Configure(UnitTypeV10 t){
        type=t;
        var c=GetComponent<CombatUnit>();
        var u=GetComponent<UnitController>();
        if(c==null) return;

        if(type==UnitTypeV10.Tank){
            c.maxHealth=180; c.damage=22; c.attackRange=10; 
            transform.localScale=new Vector3(1.5f,.65f,2f);
            if(u) u.moveSpeed=2.2f;
        } else if(type==UnitTypeV10.Scout){
            c.maxHealth=55; c.damage=7; c.attackRange=8;
            transform.localScale=new Vector3(.65f,.8f,.65f);
            if(u) u.moveSpeed=5.5f;
        } else {
            c.maxHealth=80; c.damage=10; c.attackRange=7;
            transform.localScale=new Vector3(.7f,1f,.7f);
            if(u) u.moveSpeed=3.8f;
        }
    }
}
