
using UnityEngine;

public class MapBuilderV10 : MonoBehaviour
{
    public int size=70;

    void Start(){
        GameObject ground=GameObject.CreatePrimitive(PrimitiveType.Plane);
        ground.name="Large_Battlefield";
        ground.transform.localScale=new Vector3(size/10f,1,size/10f);

        for(int i=0;i<5;i++){
            GameObject rock=GameObject.CreatePrimitive(PrimitiveType.Cube);
            rock.name="Cover_"+i;
            rock.transform.position=new Vector3(Random.Range(-25,25),.5f,Random.Range(-25,25));
            rock.transform.localScale=new Vector3(Random.Range(2,5),1,Random.Range(2,5));
        }
    }
}
