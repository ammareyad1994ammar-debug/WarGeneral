
using UnityEngine;

public class ShopV11 : MonoBehaviour
{
    public EconomyV11 economy;

    public bool BuyReinforcement(){
        if(economy==null) return false;
        return economy.Spend(30);
    }

    public bool BuyScout(){
        if(economy==null) return false;
        return economy.Spend(40);
    }
}
