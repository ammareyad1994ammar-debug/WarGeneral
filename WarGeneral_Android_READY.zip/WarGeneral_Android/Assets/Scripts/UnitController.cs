
using UnityEngine;

public class UnitController : MonoBehaviour
{
    public float speed = 4f;
    // Backward-compatible alias used by older prototype scripts.
    public float moveSpeed { get => speed; set => speed = value; }
    Vector3 target;
    bool moving;

    void Start(){ target = transform.position; }

    void Update()
    {
        if (!moving) return;
        transform.position = Vector3.MoveTowards(transform.position, target, speed * Time.deltaTime);
        if (Vector3.Distance(transform.position, target) < 0.05f) moving = false;
    }

    public void MoveTo(Vector3 point)
    {
        target = new Vector3(point.x, transform.position.y, point.z);
        moving = true;
    }
}
