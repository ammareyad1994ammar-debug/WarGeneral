
using UnityEngine;
using UnityEngine.UI;

public class MissionSystemV12 : MonoBehaviour
{
    public int missionIndex = 1;
    public int enemiesDefeated = 0;
    public int target = 5;
    public Text missionText;

    void Update(){
        if(missionText!=null)
            missionText.text = "المهمة " + missionIndex + " | التقدم: " +
                               Mathf.Min(enemiesDefeated,target) + "/" + target;
    }

    public void EnemyDefeated(){
        enemiesDefeated++;
        if(enemiesDefeated >= target) CompleteMission();
    }

    void CompleteMission(){
        var economy=FindObjectOfType<EconomyV11>();
        if(economy!=null) economy.Add(100);
        missionIndex++;
        enemiesDefeated=0;
        target += 2;
    }
}
