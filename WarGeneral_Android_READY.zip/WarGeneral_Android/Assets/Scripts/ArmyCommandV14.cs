
using System.Collections.Generic;
using UnityEngine;

public class ArmyCommandV14 : MonoBehaviour
{
    public List<CombatUnit> selectedUnits = new List<CombatUnit>();

    public void SelectUnit(CombatUnit unit){
        if(unit==null || unit.team!=0) return;
        if(!selectedUnits.Contains(unit)) selectedUnits.Add(unit);
    }

    public void ClearSelection(){ selectedUnits.Clear(); }

    public void SelectAllFriendly(){
        selectedUnits.Clear();
        foreach(var u in FindObjectsOfType<CombatUnit>())
            if(u!=null && u.team==0) selectedUnits.Add(u);
    }

    public void MoveArmy(Vector3 destination){
        int i=0;
        foreach(var u in selectedUnits){
            if(u==null) continue;
            var mover=u.GetComponent<UnitController>();
            if(mover!=null){
                Vector3 offset=new Vector3((i%3)*2f,0,(i/3)*2f);
                mover.MoveTo(destination+offset);
                i++;
            }
        }
    }

    public void AttackArmy(){
        foreach(var u in selectedUnits){
            if(u==null) continue;
            u.attackRange += 3f;
        }
    }

    public int Count(){
        selectedUnits.RemoveAll(x=>x==null);
        return selectedUnits.Count;
    }
}
