
using UnityEngine;

public class WaveSpawnerV9 : MonoBehaviour
{
    public int enemiesPerWave = 3;
    public float interval = 3f;
    float timer;

    void Update(){
        timer += Time.deltaTime;
        if(timer >= interval){
            timer = 0;
            SpawnEnemy();
        }
    }

    void SpawnEnemy(){
        Vector3 p = transform.position + new Vector3(Random.Range(-8f,8f),1f,Random.Range(-8f,8f));
        GameObject go = GameObject.CreatePrimitive(PrimitiveType.Capsule);
        go.name="Enemy_Wave";
        go.transform.position=p;
        go.transform.localScale=new Vector3(.8f,1f,.8f);
        var uc=go.AddComponent<UnitController>();
        uc.moveSpeed=2.5f;
        var cu=go.AddComponent<CombatUnit>();
        cu.maxHealth=45;
        cu.damage=6;
        cu.attackRange=6;
        cu.team=1;
    }
}
