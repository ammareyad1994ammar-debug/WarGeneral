
using UnityEngine;

public class HealthBar : MonoBehaviour
{
    public CombatUnit unit;
    GameObject bar, fill;
    float height = 1.8f;

    void Start()
    {
        if (!unit) unit = GetComponent<CombatUnit>();
        bar = GameObject.CreatePrimitive(PrimitiveType.Cube);
        bar.name = "HealthBar";
        bar.transform.SetParent(transform);
        bar.transform.localPosition = Vector3.up * height;
        bar.transform.localScale = new Vector3(1.3f, 0.08f, 0.08f);
        Destroy(bar.GetComponent<Collider>());
        var bm = new Material(Shader.Find("Standard"));
        bm.color = Color.black;
        bar.GetComponent<Renderer>().material = bm;

        fill = GameObject.CreatePrimitive(PrimitiveType.Cube);
        fill.name = "HealthFill";
        fill.transform.SetParent(bar.transform);
        fill.transform.localPosition = new Vector3(-0.5f, 0, -0.01f);
        fill.transform.localScale = new Vector3(0.98f, 0.9f, 0.8f);
        Destroy(fill.GetComponent<Collider>());
        var fm = new Material(Shader.Find("Standard"));
        fm.color = Color.green;
        fill.GetComponent<Renderer>().material = fm;
    }

    void LateUpdate()
    {
        if (!unit || !fill) return;
        float ratio = Mathf.Clamp01(unit.CurrentHealth / unit.maxHealth);
        fill.transform.localScale = new Vector3(Mathf.Max(0.02f, ratio) * 0.98f, 0.9f, 0.8f);
        fill.transform.localPosition = new Vector3((ratio - 1f) * 0.5f, 0, -0.01f);
        if (Camera.main) bar.transform.rotation = Camera.main.transform.rotation;
    }
}
