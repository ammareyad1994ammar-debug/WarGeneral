
using UnityEngine;

public class CombatUnit : MonoBehaviour
{
    // 0 = player, 1 = enemy
    public int team = 0;
    public float maxHealth = 100f;
    public float attackRange = 12f;
    public float damage = 25f;
    public float attackCooldown = 1f;
    float health;
    public float CurrentHealth => health;
    float nextAttack;

    void Start() { health = maxHealth; if (GetComponent<HealthBar>() == null) gameObject.AddComponent<HealthBar>().unit = this; }

    void Update()
    {
        if (Time.time < nextAttack) return;

        CombatUnit target = FindNearestEnemy();
        if (target != null && Vector3.Distance(transform.position, target.transform.position) <= attackRange)
        {
            nextAttack = Time.time + attackCooldown;
            target.TakeDamage(damage);
            CreateShotEffect(target.transform.position);
        }
    }

    CombatUnit FindNearestEnemy()
    {
        CombatUnit[] all = FindObjectsOfType<CombatUnit>();
        CombatUnit best = null;
        float bestD = float.MaxValue;
        foreach (var u in all)
        {
            if (u == this) continue;
            if (u.team == team) continue;

            float d = Vector3.Distance(transform.position, u.transform.position);
            if (d < bestD) { bestD = d; best = u; }
        }
        return best;
    }

    public void TakeDamage(float amount)
    {
        health -= amount;
        if (health <= 0) { ExplosionEffectV5.Spawn(transform.position); Destroy(gameObject); }
    }

    void CreateShotEffect(Vector3 target)
    {
        GameObject fx = GameObject.CreatePrimitive(PrimitiveType.Sphere);
        fx.name = "ProjectileEffect";
        fx.transform.position = transform.position + Vector3.up * 0.6f;
        fx.transform.localScale = Vector3.one * 0.12f;
        var mat = new Material(Shader.Find("Standard"));
        mat.color = Color.yellow;
        fx.GetComponent<Renderer>().material = mat;
        Destroy(fx, 0.08f);
    }
}
