
using UnityEngine;

public class MobileCameraV12 : MonoBehaviour
{
    public float panSpeed=0.08f;
    public float zoomSpeed=2f;
    public float minHeight=8f;
    public float maxHeight=35f;

    void Update(){
        if(Input.touchCount==1){
            Touch t=Input.GetTouch(0);
            if(t.phase==TouchPhase.Moved){
                Vector3 d=new Vector3(-t.deltaPosition.x*panSpeed,0,-t.deltaPosition.y*panSpeed);
                transform.position += d;
            }
        }
        if(Input.touchCount==2){
            Touch a=Input.GetTouch(0), b=Input.GetTouch(1);
            Vector2 prevA=a.position-a.deltaPosition;
            Vector2 prevB=b.position-b.deltaPosition;
            float oldDist=Vector2.Distance(prevA,prevB);
            float newDist=Vector2.Distance(a.position,b.position);
            float delta=newDist-oldDist;
            Vector3 p=transform.position;
            p.y=Mathf.Clamp(p.y-delta*zoomSpeed*0.01f,minHeight,maxHeight);
            transform.position=p;
        }
    }
}
