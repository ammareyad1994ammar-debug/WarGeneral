
using UnityEngine;
using UnityEngine.UI;

public class MobileHUDV13 : MonoBehaviour
{
    public Text selectedText;
    public Text coinsText;
    public Text statusText;
    public GameObject resultPanel;
    public Text resultText;

    void Update(){
        var eco=FindObjectOfType<EconomyV11>();
        if(eco!=null && coinsText!=null) coinsText.text="العملات: "+eco.coins;

        var sel=FindObjectOfType<UnitSelectionV12>();
        if(sel!=null && selectedText!=null)
            selectedText.text=sel.selected==null ? "لم يتم اختيار وحدة" : "الوحدة: "+sel.selected.name;
    }

    public void ShowMessage(string msg){
        if(statusText!=null) statusText.text=msg;
    }

    public void ShowVictory(){
        if(resultPanel!=null) resultPanel.SetActive(true);
        if(resultText!=null) resultText.text="انتصار!\nتم إنجاز المهمة.";
    }

    public void ShowDefeat(){
        if(resultPanel!=null) resultPanel.SetActive(true);
        if(resultText!=null) resultText.text="انتهت المهمة\nحاول مرة أخرى.";
    }

    public void HideResult(){
        if(resultPanel!=null) resultPanel.SetActive(false);
    }
}
