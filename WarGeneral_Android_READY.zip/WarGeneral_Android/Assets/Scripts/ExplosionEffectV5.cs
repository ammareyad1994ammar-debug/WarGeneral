
using UnityEngine;

public class ExplosionEffectV5 : MonoBehaviour
{
    public static void Spawn(Vector3 position)
    {
        GameObject fx = GameObject.CreatePrimitive(PrimitiveType.Sphere);
        fx.name = "ExplosionFX";
        fx.transform.position = position + Vector3.up * 0.5f;
        fx.transform.localScale = Vector3.one * 0.3f;
        var mat = new Material(Shader.Find("Standard"));
        mat.color = new Color(1f, 0.35f, 0.05f);
        fx.GetComponent<Renderer>().material = mat;

        GameObject lightObj = new GameObject("ExplosionLight");
        lightObj.transform.position = fx.transform.position;
        var light = lightObj.AddComponent<Light>();
        light.type = LightType.Point;
        light.range = 7f;
        light.intensity = 7f;

        Destroy(fx, 0.35f);
        Destroy(lightObj, 0.2f);
    }
}
