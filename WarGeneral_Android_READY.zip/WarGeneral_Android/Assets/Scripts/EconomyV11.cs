
using UnityEngine;

public class EconomyV11 : MonoBehaviour
{
    public int coins = 250;
    public int missionReward = 50;

    public bool Spend(int amount){
        if(coins < amount) return false;
        coins -= amount;
        return true;
    }

    public void Add(int amount){ coins += Mathf.Max(0,amount); }
}
