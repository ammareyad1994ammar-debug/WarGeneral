
using UnityEngine;

public class BattleSystemsV9 : MonoBehaviour
{
    public static BattleSystemsV9 Instance;
    public int supplies = 100;
    public int score = 0;
    public int wave = 1;

    void Awake(){ Instance=this; }

    public void Reward(int amount){
        supplies += amount;
        score += amount;
    }

    public bool Spend(int amount){
        if(supplies < amount) return false;
        supplies -= amount;
        return true;
    }
}
