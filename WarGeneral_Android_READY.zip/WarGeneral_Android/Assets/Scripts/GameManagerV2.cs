
using UnityEngine;
using UnityEngine.UI;

public class GameManagerV2 : MonoBehaviour
{
    public Transform enemyBase;
    public Text missionText;
    public float winDistance = 4f;
    bool finished;

    void Update()
    {
        if (finished || enemyBase == null) return;
        UnitController[] units = FindObjectsOfType<UnitController>();
        foreach (var u in units)
        {
            if (u.name.StartsWith("Friendly") && Vector3.Distance(u.transform.position, enemyBase.position) < winDistance)
            {
                finished = true;
                if (missionText) missionText.text = "انتصار! تم احتلال قاعدة العدو.";
                break;
            }
        }
    }
}
