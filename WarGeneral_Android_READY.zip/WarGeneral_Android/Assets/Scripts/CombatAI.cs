using UnityEngine;

// Lightweight enemy AI for the mobile prototype.
public class CombatAI : MonoBehaviour
{
    public float chaseRange = 25f;
    public float stopRange = 10f;
    public float thinkInterval = 0.25f;
    float nextThink;
    CombatUnit unit;
    UnitController mover;

    void Awake()
    {
        unit = GetComponent<CombatUnit>();
        mover = GetComponent<UnitController>();
    }

    void Update()
    {
        if (unit == null || unit.team == 0 || mover == null || Time.time < nextThink) return;
        nextThink = Time.time + thinkInterval;

        CombatUnit target = FindNearestPlayer();
        if (target == null) return;

        float d = Vector3.Distance(transform.position, target.transform.position);
        if (d <= chaseRange && d > stopRange)
            mover.MoveTo(target.transform.position);
    }

    CombatUnit FindNearestPlayer()
    {
        CombatUnit best = null;
        float bestDistance = float.MaxValue;
        foreach (var candidate in FindObjectsOfType<CombatUnit>())
        {
            if (candidate == null || candidate == unit || candidate.team != 0) continue;
            float d = (candidate.transform.position - transform.position).sqrMagnitude;
            if (d < bestDistance) { bestDistance = d; best = candidate; }
        }
        return best;
    }
}
