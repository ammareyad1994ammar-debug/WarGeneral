
using UnityEngine;

public class MobileControlsV5 : MonoBehaviour
{
    public Camera cam;
    public UnitController selected;

    void Update()
    {
        if (Input.touchCount == 0 && !Input.GetMouseButtonDown(0)) return;

        Vector2 screen;
        if (Input.touchCount > 0 && Input.GetTouch(0).phase == TouchPhase.Began)
            screen = Input.GetTouch(0).position;
        else if (Input.GetMouseButtonDown(0))
            screen = Input.mousePosition;
        else return;

        Ray ray = cam.ScreenPointToRay(screen);
        if (!Physics.Raycast(ray, out RaycastHit hit, 500f)) return;

        UnitController unit = hit.collider.GetComponentInParent<UnitController>();
        if (unit != null && unit.name.StartsWith("Friendly"))
        {
            selected = unit;
            return;
        }

        if (selected != null)
            selected.MoveTo(hit.point);
    }
}
