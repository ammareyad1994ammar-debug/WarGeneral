
using UnityEngine;

public class FormationV14 : MonoBehaviour
{
    public enum Formation { Line, Column, Wedge }
    public Formation formation=Formation.Line;

    public Vector3 GetOffset(int index){
        if(formation==Formation.Column)
            return new Vector3(0,0,index*2f);
        if(formation==Formation.Wedge){
            int row=index/2;
            int side=(index%2==0)?-1:1;
            return new Vector3(side*row*1.8f,0,row*2f);
        }
        return new Vector3(index*2f,0,0);
    }
}
