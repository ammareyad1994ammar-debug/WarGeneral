
using UnityEngine;

public class StartScreenV13 : MonoBehaviour
{
    public GameObject startPanel;

    void Start(){
        Time.timeScale=0f;
        if(startPanel!=null) startPanel.SetActive(true);
    }

    public void StartGame(){
        Time.timeScale=1f;
        if(startPanel!=null) startPanel.SetActive(false);
    }

    public void Pause(){
        Time.timeScale=0f;
    }

    public void Resume(){
        Time.timeScale=1f;
    }
}
