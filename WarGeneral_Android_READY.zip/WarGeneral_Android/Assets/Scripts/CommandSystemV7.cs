
using UnityEngine;

public class CommandSystemV7 : MonoBehaviour
{
    public MobileControlsV5 controls;
    public float defenseBonus = 0.5f;

    public void Attack()
    {
        if (controls && controls.selected)
        {
            CombatUnit u = controls.selected.GetComponent<CombatUnit>();
            if (u) u.attackRange += 3f;
        }
    }

    public void Defend()
    {
        if (controls && controls.selected)
        {
            CombatUnit u = controls.selected.GetComponent<CombatUnit>();
            if (u) u.maxHealth += 20f;
        }
    }

    public void Reinforce()
    {
        if (!controls || !controls.selected) return;
        Vector3 p = controls.selected.transform.position + new Vector3(1.5f, 0, 1.5f);
        GameObject s = GameObject.CreatePrimitive(PrimitiveType.Capsule);
        s.name = "FriendlyReinforcement";
        s.transform.position = p + Vector3.up * 0.7f;
        s.transform.localScale = new Vector3(.35f,.7f,.35f);
        var mat = new Material(Shader.Find("Standard"));
        mat.color = new Color(.08f,.28f,.12f);
        s.GetComponent<Renderer>().material = mat;
        s.AddComponent<UnitController>();
        var combat = s.AddComponent<CombatUnit>();
        combat.team = controls.selected.GetComponent<CombatUnit>()?.team ?? 0;
    }
}
