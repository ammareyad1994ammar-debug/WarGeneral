
using UnityEngine;
using UnityEngine.SceneManagement;

public class ResultsV13 : MonoBehaviour
{
    public void Restart(){
        Time.timeScale=1f;
        SceneManager.LoadScene(SceneManager.GetActiveScene().buildIndex);
    }
}
