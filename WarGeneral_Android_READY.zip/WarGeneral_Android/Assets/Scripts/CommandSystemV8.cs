
using UnityEngine;

public class CommandSystemV8 : MonoBehaviour
{
    public CombatUnit selected;
    public void SetSelected(CombatUnit unit){ selected = unit; }
    public void Attack(){
        if(selected == null) return;
        selected.attackRange += 8f;
        selected.damage += 2;
    }
    public void Defend(){
        if(selected == null) return;
        selected.maxHealth += 25;
        selected.SendMessage("RestoreFullHealth", SendMessageOptions.DontRequireReceiver);
    }
    public void Reinforce(){
        if(selected == null) return;
        GameObject go = GameObject.CreatePrimitive(PrimitiveType.Capsule);
        go.name = "Reinforcement";
        go.transform.position = selected.transform.position + new Vector3(2.5f,1f,0);
        go.transform.localScale = new Vector3(.8f,1f,.8f);
        var uc = go.AddComponent<UnitController>();
        uc.moveSpeed = 4f;
        var cu = go.AddComponent<CombatUnit>();
        cu.maxHealth = 60;
        cu.damage = 8;
        cu.attackRange = 7;
        cu.team = selected.team;
        var col = go.GetComponent<Collider>();
        if(col) col.isTrigger = false;
    }
}
