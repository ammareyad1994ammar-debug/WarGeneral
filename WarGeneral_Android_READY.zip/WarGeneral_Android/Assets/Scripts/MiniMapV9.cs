
using UnityEngine;

public class MiniMapV9 : MonoBehaviour
{
    public Transform target;
    public float height=45f;

    void LateUpdate(){
        if(target==null) return;
        transform.position = new Vector3(target.position.x,height,target.position.z);
        transform.rotation = Quaternion.Euler(90,0,0);
    }
}
