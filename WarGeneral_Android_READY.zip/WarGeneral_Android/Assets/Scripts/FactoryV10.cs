
using UnityEngine;

public class FactoryV10 : MonoBehaviour
{
    public GameObject Spawn(UnitTypeV10 type, Vector3 pos, int team){
        GameObject go=GameObject.CreatePrimitive(type==UnitTypeV10.Tank ? PrimitiveType.Cube : PrimitiveType.Capsule);
        go.name=type.ToString()+"_Unit";
        go.transform.position=pos;
        var uc=go.AddComponent<UnitController>();
        var cu=go.AddComponent<CombatUnit>();
        cu.team=team;
        var ut=go.AddComponent<UnitTypesV10>();
        ut.Configure(type);
        return go;
    }
}
