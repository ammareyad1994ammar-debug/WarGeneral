
using UnityEngine;
public class RTSCamera : MonoBehaviour
{
    public float moveSpeed=18f, zoomSpeed=8f, minHeight=8f, maxHeight=30f;
    void Update()
    {
        Vector3 move = new Vector3(Input.GetAxisRaw("Horizontal"),0,Input.GetAxisRaw("Vertical"));
        transform.position += move.normalized*moveSpeed*Time.deltaTime;
        float scroll=Input.mouseScrollDelta.y;
        Vector3 p=transform.position;
        p.y=Mathf.Clamp(p.y-scroll*zoomSpeed,minHeight,maxHeight);
        transform.position=p;
    }
}
