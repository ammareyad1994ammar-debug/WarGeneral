
using UnityEngine;

public class UnitSelectionV12 : MonoBehaviour
{
    public CombatUnit selected;

    void Update(){
        if(!Input.GetMouseButtonDown(0)) return;
        Ray ray=Camera.main.ScreenPointToRay(Input.mousePosition);
        if(Physics.Raycast(ray,out RaycastHit hit,300f)){
            var unit=hit.collider.GetComponentInParent<CombatUnit>();
            if(unit!=null && unit.team==0){
                selected=unit;
                Debug.Log("Selected: "+unit.name);
            }
        }
    }
}
