
using UnityEngine;
using UnityEngine.UI;

public class ArmyHUDV14 : MonoBehaviour
{
    public Text armyText;
    public ArmyCommandV14 army;

    void Update(){
        if(army!=null && armyText!=null)
            armyText.text="الجيش المحدد: "+army.Count();
    }

    public void SelectAll(){ if(army!=null) army.SelectAllFriendly(); }
    public void Clear(){ if(army!=null) army.ClearSelection(); }
}
