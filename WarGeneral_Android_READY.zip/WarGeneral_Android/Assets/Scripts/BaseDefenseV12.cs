
using UnityEngine;

public class BaseDefenseV12 : MonoBehaviour
{
    public int health=1000;
    public int maxHealth=1000;

    public void TakeDamage(int amount){
        health=Mathf.Max(0,health-amount);
        if(health==0) Debug.Log("القاعدة تحتاج إلى إعادة بناء");
    }

    public void Repair(int amount){
        health=Mathf.Min(maxHealth,health+amount);
    }
}
