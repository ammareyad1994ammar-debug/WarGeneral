
using UnityEngine;

public class RewardManagerV11 : MonoBehaviour
{
    public EconomyV11 economy;

    public void MissionComplete(){
        if(economy!=null) economy.Add(economy.missionReward);
    }
}
