
using UnityEngine;
using UnityEngine.UI;

public class MissionManagerV4 : MonoBehaviour
{
    public Text missionText;
    public Text statusText;
    public Transform enemyBase;
    int stage = 0;
    bool finished;

    void Update()
    {
        if (finished) return;

        CombatUnit[] enemies = FindObjectsOfType<CombatUnit>();
        int enemyCount = 0;
        foreach (var e in enemies)
            if (e.name.StartsWith("Enemy")) enemyCount++;

        if (stage == 0 && enemyCount <= 1)
        {
            stage = 1;
            if (missionText) missionText.text = "المهمة 2: اقترب من قاعدة العدو";
        }

        if (stage == 1)
        {
            UnitController[] units = FindObjectsOfType<UnitController>();
            foreach (var u in units)
            {
                if (u.name.StartsWith("Friendly") &&
                    Vector3.Distance(u.transform.position, enemyBase.position) < 4.5f)
                {
                    stage = 2;
                    if (missionText) missionText.text = "المهمة 3: تم احتلال القاعدة — انتظر التأكيد";
                    Invoke(nameof(Win), 1.5f);
                    break;
                }
            }
        }

        if (enemyCount == 0)
        {
            Win();
        }
    }

    void Win()
    {
        if (finished) return;
        finished = true;
        if (missionText) missionText.text = "🏆 انتصار! اكتملت المهمة.";
        if (statusText) statusText.text = "VICTORY";
    }
}
