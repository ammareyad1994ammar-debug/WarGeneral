
using UnityEngine;

public static class RestoreHealthV8
{
    public static void RestoreFullHealth(this CombatUnit u)
    {
        // Extension method placeholder; current CombatUnit keeps health private.
        // Visual command feedback is handled by maxHealth increase.
    }
}
