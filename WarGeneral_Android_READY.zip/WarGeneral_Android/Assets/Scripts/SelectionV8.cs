
using UnityEngine;

public class SelectionV8 : MonoBehaviour
{
    public CombatUnit selected;
    GameObject ring;

    void Update(){
        if(Input.GetMouseButtonDown(0)){
            Ray r=Camera.main.ScreenPointToRay(Input.mousePosition);
            if(Physics.Raycast(r,out RaycastHit h,200f)){
                var u=h.collider.GetComponentInParent<CombatUnit>();
                if(u!=null) Select(u);
            }
        }
        if(selected!=null && ring!=null) ring.transform.position =
            selected.transform.position + Vector3.up * 0.08f;
    }

    public void Select(CombatUnit u){
        selected=u;
        if(ring==null){
            ring=GameObject.CreatePrimitive(PrimitiveType.Cylinder);
            ring.name="SelectionRing";
            ring.transform.localScale=new Vector3(1.8f,.03f,1.8f);
            var c=ring.GetComponent<Collider>(); if(c) Destroy(c);
            var m=ring.GetComponent<Renderer>().material;
            m.color=new Color(1f,.75f,.1f,.85f);
        }
        ring.transform.position=u.transform.position+Vector3.up*.08f;
    }
}
