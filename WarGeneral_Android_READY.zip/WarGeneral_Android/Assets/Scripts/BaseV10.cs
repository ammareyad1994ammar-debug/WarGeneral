
using UnityEngine;

public class BaseV10 : MonoBehaviour
{
    public int health=1000;
    public int team=0;

    public void TakeDamage(int amount){
        health-=amount;
        if(health<=0) Destroy(gameObject);
    }
}
